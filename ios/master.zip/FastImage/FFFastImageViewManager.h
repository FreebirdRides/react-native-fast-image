#import <React/RCTViewManager.h>

@interface FFFastImageViewManager : RCTViewManager

@end
